package com.example.demo.dao;

import com.example.demo.pojo.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentDao {

    /*@Select("select * from student")*/
    List<Student> findAll();

    @Insert("insert into student values(#{id},#{name},#{age},#{clsid},#{origin},#{address},#{phone})")
    int add(Student student);

    @Update("update student set name=#{name},phone=#{phone} where id=#{id}")
    int update(Student student);

    @Delete("delete from student where id=#{id}")
    int delete(int i);
}
