package com.example.demo.controller;

import com.example.demo.pojo.Student;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("findAll")
    public Object findAll(){
        List<Student> list=studentService.findAll();
        return list;
    }
    @RequestMapping("add")
    public Object add(){
        Student student = new Student();
        student.setId(2);
        student.setName("李四");
        student.setAge(25);
        student.setClsid(3);
        student.setOrigin("河北省");
        student.setAddress("石家庄");
        student.setPhone("13545689685");
        int i=studentService.add(student);
        if(i>0){
            return "添加成功";
        }else {
            return "添加失败";
        }
    }
    @RequestMapping("update")
    public Object update(){
        Student student = new Student();
        student.setId(2);
        student.setName("王五");
        student.setPhone("18888888888");
        int i=studentService.update(student);
        if(i>0){
            return "修改成功";
        }else {
            return "修改失败";
        }
    }
    @RequestMapping("delete")
    public Object delete(){
        int i=studentService.delete(2);
        if(i>0){
            return "删除成功";
        }else {
            return "删除失败";
        }
    }
}
