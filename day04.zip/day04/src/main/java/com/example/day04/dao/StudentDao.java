package com.example.day04.dao;

import com.example.day04.pojo.Student;

import java.util.List;

public interface StudentDao {

    List<Student> findAll();

    int add(Student student);

    int edit(Student student);

    int delete(Integer id);
}
