package com.example.day03.controller;

import com.example.day03.Service.StudentService;
import com.example.day03.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @CrossOrigin
    @RequestMapping("findAll")
    public Object findAll(){
        List<Student> list=studentService.findAll();
        return list;
    }

    @CrossOrigin
    @RequestMapping("add")
    public Object add(@RequestBody Student student){
       int i=0;
       i=studentService.add(student);
       return i;
    }
    @CrossOrigin
    @RequestMapping("update")
    public Object update(@RequestBody Student student){
       int i=0;
       i=studentService.update(student);
       return i;
    }
    @CrossOrigin
    @RequestMapping("/delete/{id}")
    public Object deleteStudent(@PathVariable("id") Integer id){
        int i =0;
        i=studentService.delete(id);
        return i;
    }
}
