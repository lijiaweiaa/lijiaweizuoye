package com.example.day03.dao;

import com.example.day03.pojo.Student;

import java.util.List;

public interface StudentDao {

    List<Student> findAll();

    int add(Student student);

    int update(Student student);

    int delete(Integer id);
}
