package com.example.day03.Service;

import com.example.day03.pojo.Student;

import java.util.List;

public interface StudentService {

    List<Student> findAll();

    int add(Student student);

    int update(Student student);

    int delete(Integer id);
}
