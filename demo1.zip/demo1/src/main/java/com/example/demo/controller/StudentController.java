package com.example.demo.controller;

import com.example.demo.pojo.Student;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("findAll")
    public Object findAll(){
        List<Student> studentList=studentService.getList();
        return studentList;
    }
    @RequestMapping("add")
    public Object add(){
        Student student = new Student();
        student.setId(3);
        student.setName("李四");
        student.setSex("男");
        student.setHobby("跳舞");
        student.setAddress("天津");
        student.setBirthday(new Date("2022/9/8"));
       int i= studentService.add(student);
       if(i>0){
           return "添加成功";
       }else {
           return "添加失败";
       }
    }
    @RequestMapping("update")
    public Object update(){
        Student student = new Student();
        student.setId(2);
        student.setBirthday(new Date("1997/9/8"));
       int i= studentService.update(student);
       if(i>0){
           return "修改成功";
       }else {
           return "修改失败";
       }
    }
}
