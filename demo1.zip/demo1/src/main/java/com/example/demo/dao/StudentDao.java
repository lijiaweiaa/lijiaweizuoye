package com.example.demo.dao;

import com.example.demo.pojo.Student;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface StudentDao {


    @Select("select * from student")
    List<Student> getList();

    @Insert("insert into student values(#{id},#{name},#{sex},#{hobby},#{address},#{birthday})")
    int add(Student student);

    @Update("update student set birthday=#{birthday} where id=#{id}")
    int update(Student student);
}
