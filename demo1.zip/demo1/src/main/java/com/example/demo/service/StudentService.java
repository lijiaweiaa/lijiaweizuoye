package com.example.demo.service;

import com.example.demo.pojo.Student;

import java.util.List;

public interface StudentService {


    List<Student> getList();

    int add(Student student);

    int update(Student student);
}
